<?php
$world = array(
    array(
        'id'        => 4,
        'name'      => 'อัฟกานิสถาน',
        'alpha2'    => 'af',
        'alpha3'    => 'afg'
    ),
    array(
        'id'        => 248,
        'name'      => 'หมู่เกาะโอลันด์',
        'alpha2'    => 'ax',
        'alpha3'    => 'ala'
    ),
    array(
        'id'        => 8,
        'name'      => 'แอลเบเนีย',
        'alpha2'    => 'al',
        'alpha3'    => 'alb'
    ),
    array(
        'id'        => 12,
        'name'      => 'แอลจีเรีย',
        'alpha2'    => 'dz',
        'alpha3'    => 'dza'
    ),
    array(
        'id'        => 16,
        'name'      => 'อเมริกันซามัว',
        'alpha2'    => 'as',
        'alpha3'    => 'asm'
    ),
    array(
        'id'        => 20,
        'name'      => 'อันดอร์รา',
        'alpha2'    => 'ad',
        'alpha3'    => 'and'
    ),
    array(
        'id'        => 24,
        'name'      => 'แองโกลา',
        'alpha2'    => 'ao',
        'alpha3'    => 'ago'
    ),
    array(
        'id'        => 660,
        'name'      => 'แองกวิลลา',
        'alpha2'    => 'ai',
        'alpha3'    => 'aia'
    ),
    array(
        'id'        => 10,
        'name'      => 'แอนตาร์กติกา',
        'alpha2'    => 'aq',
        'alpha3'    => 'ata'
    ),
    array(
        'id'        => 28,
        'name'      => 'แอนติกาและบาร์บูดา',
        'alpha2'    => 'ag',
        'alpha3'    => 'atg'
    ),
    array(
        'id'        => 32,
        'name'      => 'อาร์เจนตินา',
        'alpha2'    => 'ar',
        'alpha3'    => 'arg'
    ),
    array(
        'id'        => 51,
        'name'      => 'อาร์มีเนีย',
        'alpha2'    => 'am',
        'alpha3'    => 'arm'
    ),
    array(
        'id'        => 533,
        'name'      => 'อารูบา',
        'alpha2'    => 'aw',
        'alpha3'    => 'abw'
    ),
    array(
        'id'        => 36,
        'name'      => 'ออสเตรเลีย',
        'alpha2'    => 'au',
        'alpha3'    => 'aus'
    ),
    array(
        'id'        => 40,
        'name'      => 'ออสเตรีย',
        'alpha2'    => 'at',
        'alpha3'    => 'aut'
    ),
    array(
        'id'        => 31,
        'name'      => 'อาเซอร์ไบจาน',
        'alpha2'    => 'az',
        'alpha3'    => 'aze'
    ),
    array(
        'id'        => 44,
        'name'      => 'บาฮามาส',
        'alpha2'    => 'bs',
        'alpha3'    => 'bhs'
    ),
    array(
        'id'        => 48,
        'name'      => 'บาห์เรน',
        'alpha2'    => 'bh',
        'alpha3'    => 'bhr'
    ),
    array(
        'id'        => 50,
        'name'      => 'บังกลาเทศ',
        'alpha2'    => 'bd',
        'alpha3'    => 'bgd'
    ),
    array(
        'id'        => 52,
        'name'      => 'บาร์เบโดส',
        'alpha2'    => 'bb',
        'alpha3'    => 'brb'
    ),
    array(
        'id'        => 112,
        'name'      => 'เบลารุส',
        'alpha2'    => 'by',
        'alpha3'    => 'blr'
    ),
    array(
        'id'        => 56,
        'name'      => 'เบลเยียม',
        'alpha2'    => 'be',
        'alpha3'    => 'bel'
    ),
    array(
        'id'        => 84,
        'name'      => 'เบลีซ',
        'alpha2'    => 'bz',
        'alpha3'    => 'blz'
    ),
    array(
        'id'        => 204,
        'name'      => 'เบนิน',
        'alpha2'    => 'bj',
        'alpha3'    => 'ben'
    ),
    array(
        'id'        => 60,
        'name'      => 'เบอร์มิวดา',
        'alpha2'    => 'bm',
        'alpha3'    => 'bmu'
    ),
    array(
        'id'        => 64,
        'name'      => 'ภูฏาน',
        'alpha2'    => 'bt',
        'alpha3'    => 'btn'
    ),
    array(
        'id'        => 68,
        'name'      => 'โบลิเวีย',
        'alpha2'    => 'bo',
        'alpha3'    => 'bol'
    ),
    array(
        'id'        => 535,
        'name'      => 'เนเธอร์แลนด์แอนทิลลีส',
        'alpha2'    => 'bq',
        'alpha3'    => 'bes'
    ),
    array(
        'id'        => 70,
        'name'      => 'บอสเนียและเฮอร์เซโกวีนา',
        'alpha2'    => 'ba',
        'alpha3'    => 'bih'
    ),
    array(
        'id'        => 72,
        'name'      => 'บอตสวานา',
        'alpha2'    => 'bw',
        'alpha3'    => 'bwa'
    ),
    array(
        'id'        => 74,
        'name'      => 'เกาะบูเว',
        'alpha2'    => 'bv',
        'alpha3'    => 'bvt'
    ),
    array(
        'id'        => 76,
        'name'      => 'บราซิล',
        'alpha2'    => 'br',
        'alpha3'    => 'bra'
    ),
    array(
        'id'        => 86,
        'name'      => 'บริติชอินเดียนโอเชียนเทร์ริทอรี',
        'alpha2'    => 'io',
        'alpha3'    => 'iot'
    ),
    array(
        'id'        => 96,
        'name'      => 'บรูไน',
        'alpha2'    => 'bn',
        'alpha3'    => 'brn'
    ),
    array(
        'id'        => 100,
        'name'      => 'บัลแกเรีย',
        'alpha2'    => 'bg',
        'alpha3'    => 'bgr'
    ),
    array(
        'id'        => 854,
        'name'      => 'บูร์กินาฟาโซ',
        'alpha2'    => 'bf',
        'alpha3'    => 'bfa'
    ),
    array(
        'id'        => 108,
        'name'      => 'บุรุนดี',
        'alpha2'    => 'bi',
        'alpha3'    => 'bdi'
    ),
    array(
        'id'        => 132,
        'name'      => 'กาบูเวร์ดี',
        'alpha2'    => 'cv',
        'alpha3'    => 'cpv'
    ),
    array(
        'id'        => 116,
        'name'      => 'กัมพูชา',
        'alpha2'    => 'kh',
        'alpha3'    => 'khm'
    ),
    array(
        'id'        => 120,
        'name'      => 'แคเมอรูน',
        'alpha2'    => 'cm',
        'alpha3'    => 'cmr'
    ),
    array(
        'id'        => 124,
        'name'      => 'แคนาดา',
        'alpha2'    => 'ca',
        'alpha3'    => 'can'
    ),
    array(
        'id'        => 136,
        'name'      => 'หมู่เกาะเคย์แมน',
        'alpha2'    => 'ky',
        'alpha3'    => 'cym'
    ),
    array(
        'id'        => 140,
        'name'      => 'สาธารณรัฐแอฟริกากลาง',
        'alpha2'    => 'cf',
        'alpha3'    => 'caf'
    ),
    array(
        'id'        => 148,
        'name'      => 'ชาด',
        'alpha2'    => 'td',
        'alpha3'    => 'tcd'
    ),
    array(
        'id'        => 152,
        'name'      => 'ชิลี',
        'alpha2'    => 'cl',
        'alpha3'    => 'chl'
    ),
    array(
        'id'        => 156,
        'name'      => 'จีน',
        'alpha2'    => 'cn',
        'alpha3'    => 'chn'
    ),
    array(
        'id'        => 162,
        'name'      => 'เกาะคริสต์มาส',
        'alpha2'    => 'cx',
        'alpha3'    => 'cxr'
    ),
    array(
        'id'        => 166,
        'name'      => 'หมู่เกาะโคโคส',
        'alpha2'    => 'cc',
        'alpha3'    => 'cck'
    ),
    array(
        'id'        => 170,
        'name'      => 'โคลอมเบีย',
        'alpha2'    => 'co',
        'alpha3'    => 'col'
    ),
    array(
        'id'        => 174,
        'name'      => 'คอโมโรส',
        'alpha2'    => 'km',
        'alpha3'    => 'com'
    ),
    array(
        'id'        => 178,
        'name'      => 'สาธารณรัฐคองโก',
        'alpha2'    => 'cg',
        'alpha3'    => 'cog'
    ),
    array(
        'id'        => 180,
        'name'      => 'สาธารณรัฐประชาธิปไตยคองโก',
        'alpha2'    => 'cd',
        'alpha3'    => 'cod'
    ),
    array(
        'id'        => 184,
        'name'      => 'หมู่เกาะคุก',
        'alpha2'    => 'ck',
        'alpha3'    => 'cok'
    ),
    array(
        'id'        => 188,
        'name'      => 'คอสตาริกา',
        'alpha2'    => 'cr',
        'alpha3'    => 'cri'
    ),
    array(
        'id'        => 384,
        'name'      => 'โกตดิวัวร์',
        'alpha2'    => 'ci',
        'alpha3'    => 'civ'
    ),
    array(
        'id'        => 191,
        'name'      => 'โครเอเชีย',
        'alpha2'    => 'hr',
        'alpha3'    => 'hrv'
    ),
    array(
        'id'        => 192,
        'name'      => 'คิวบา',
        'alpha2'    => 'cu',
        'alpha3'    => 'cub'
    ),
    array(
        'id'        => 531,
        'name'      => 'กือราเซา',
        'alpha2'    => 'cw',
        'alpha3'    => 'cuw'
    ),
    array(
        'id'        => 196,
        'name'      => 'ไซปรัส',
        'alpha2'    => 'cy',
        'alpha3'    => 'cyp'
    ),
    array(
        'id'        => 203,
        'name'      => 'เช็กเกีย',
        'alpha2'    => 'cz',
        'alpha3'    => 'cze'
    ),
    array(
        'id'        => 208,
        'name'      => 'เดนมาร์ก',
        'alpha2'    => 'dk',
        'alpha3'    => 'dnk'
    ),
    array(
        'id'        => 262,
        'name'      => 'จิบูตี',
        'alpha2'    => 'dj',
        'alpha3'    => 'dji'
    ),
    array(
        'id'        => 212,
        'name'      => 'ดอมินีกา',
        'alpha2'    => 'dm',
        'alpha3'    => 'dma'
    ),
    array(
        'id'        => 214,
        'name'      => 'สาธารณรัฐโดมินิกัน',
        'alpha2'    => 'do',
        'alpha3'    => 'dom'
    ),
    array(
        'id'        => 218,
        'name'      => 'เอกวาดอร์',
        'alpha2'    => 'ec',
        'alpha3'    => 'ecu'
    ),
    array(
        'id'        => 818,
        'name'      => 'อียิปต์',
        'alpha2'    => 'eg',
        'alpha3'    => 'egy'
    ),
    array(
        'id'        => 222,
        'name'      => 'เอลซัลวาดอร์',
        'alpha2'    => 'sv',
        'alpha3'    => 'slv'
    ),
    array(
        'id'        => 226,
        'name'      => 'อิเควทอเรียลกินี',
        'alpha2'    => 'gq',
        'alpha3'    => 'gnq'
    ),
    array(
        'id'        => 232,
        'name'      => 'เอริเทรีย',
        'alpha2'    => 'er',
        'alpha3'    => 'eri'
    ),
    array(
        'id'        => 233,
        'name'      => 'เอสโตเนีย',
        'alpha2'    => 'ee',
        'alpha3'    => 'est'
    ),
    array(
        'id'        => 748,
        'name'      => 'เอสวาตีนี',
        'alpha2'    => 'sz',
        'alpha3'    => 'swz'
    ),
    array(
        'id'        => 231,
        'name'      => 'เอธิโอเปีย',
        'alpha2'    => 'et',
        'alpha3'    => 'eth'
    ),
    array(
        'id'        => 238,
        'name'      => 'หมู่เกาะฟอล์กแลนด์',
        'alpha2'    => 'fk',
        'alpha3'    => 'flk'
    ),
    array(
        'id'        => 234,
        'name'      => 'หมู่เกาะแฟโร',
        'alpha2'    => 'fo',
        'alpha3'    => 'fro'
    ),
    array(
        'id'        => 242,
        'name'      => 'ฟีจี',
        'alpha2'    => 'fj',
        'alpha3'    => 'fji'
    ),
    array(
        'id'        => 246,
        'name'      => 'ฟินแลนด์',
        'alpha2'    => 'fi',
        'alpha3'    => 'fin'
    ),
    array(
        'id'        => 250,
        'name'      => 'ฝรั่งเศส',
        'alpha2'    => 'fr',
        'alpha3'    => 'fra'
    ),
    array(
        'id'        => 254,
        'name'      => 'เฟรนช์เกียนา',
        'alpha2'    => 'gf',
        'alpha3'    => 'guf'
    ),
    array(
        'id'        => 258,
        'name'      => 'เฟรนช์พอลินีเชีย',
        'alpha2'    => 'pf',
        'alpha3'    => 'pyf'
    ),
    array(
        'id'        => 260,
        'name'      => 'เฟรนช์เซาเทิร์นและแอนตาร์กติกแลนดส์',
        'alpha2'    => 'tf',
        'alpha3'    => 'atf'
    ),
    array(
        'id'        => 266,
        'name'      => 'กาบอง',
        'alpha2'    => 'ga',
        'alpha3'    => 'gab'
    ),
    array(
        'id'        => 270,
        'name'      => 'แกมเบีย',
        'alpha2'    => 'gm',
        'alpha3'    => 'gmb'
    ),
    array(
        'id'        => 268,
        'name'      => 'จอร์เจีย',
        'alpha2'    => 'ge',
        'alpha3'    => 'geo'
    ),
    array(
        'id'        => 276,
        'name'      => 'เยอรมนี',
        'alpha2'    => 'de',
        'alpha3'    => 'deu'
    ),
    array(
        'id'        => 288,
        'name'      => 'กานา',
        'alpha2'    => 'gh',
        'alpha3'    => 'gha'
    ),
    array(
        'id'        => 292,
        'name'      => 'ยิบรอลตาร์',
        'alpha2'    => 'gi',
        'alpha3'    => 'gib'
    ),
    array(
        'id'        => 300,
        'name'      => 'กรีซ',
        'alpha2'    => 'gr',
        'alpha3'    => 'grc'
    ),
    array(
        'id'        => 304,
        'name'      => 'กรีนแลนด์',
        'alpha2'    => 'gl',
        'alpha3'    => 'grl'
    ),
    array(
        'id'        => 308,
        'name'      => 'เกรเนดา',
        'alpha2'    => 'gd',
        'alpha3'    => 'grd'
    ),
    array(
        'id'        => 312,
        'name'      => 'กัวเดอลุป',
        'alpha2'    => 'gp',
        'alpha3'    => 'glp'
    ),
    array(
        'id'        => 316,
        'name'      => 'กวม',
        'alpha2'    => 'gu',
        'alpha3'    => 'gum'
    ),
    array(
        'id'        => 320,
        'name'      => 'กัวเตมาลา',
        'alpha2'    => 'gt',
        'alpha3'    => 'gtm'
    ),
    array(
        'id'        => 831,
        'name'      => 'เกิร์นซีย์',
        'alpha2'    => 'gg',
        'alpha3'    => 'ggy'
    ),
    array(
        'id'        => 324,
        'name'      => 'กินี',
        'alpha2'    => 'gn',
        'alpha3'    => 'gin'
    ),
    array(
        'id'        => 624,
        'name'      => 'กินี-บิสเซา',
        'alpha2'    => 'gw',
        'alpha3'    => 'gnb'
    ),
    array(
        'id'        => 328,
        'name'      => 'กายอานา',
        'alpha2'    => 'gy',
        'alpha3'    => 'guy'
    ),
    array(
        'id'        => 332,
        'name'      => 'เฮติ',
        'alpha2'    => 'ht',
        'alpha3'    => 'hti'
    ),
    array(
        'id'        => 334,
        'name'      => 'เกาะเฮิร์ดและหมู่เกาะแมกดอนัลด์',
        'alpha2'    => 'hm',
        'alpha3'    => 'hmd'
    ),
    array(
        'id'        => 336,
        'name'      => 'นครรัฐวาติกัน',
        'alpha2'    => 'va',
        'alpha3'    => 'vat'
    ),
    array(
        'id'        => 340,
        'name'      => 'ฮอนดูรัส',
        'alpha2'    => 'hn',
        'alpha3'    => 'hnd'
    ),
    array(
        'id'        => 344,
        'name'      => 'ฮ่องกง',
        'alpha2'    => 'hk',
        'alpha3'    => 'hkg'
    ),
    array(
        'id'        => 348,
        'name'      => 'ฮังการี',
        'alpha2'    => 'hu',
        'alpha3'    => 'hun'
    ),
    array(
        'id'        => 352,
        'name'      => 'ไอซ์แลนด์',
        'alpha2'    => 'is',
        'alpha3'    => 'isl'
    ),
    array(
        'id'        => 356,
        'name'      => 'อินเดีย',
        'alpha2'    => 'in',
        'alpha3'    => 'ind'
    ),
    array(
        'id'        => 360,
        'name'      => 'อินโดนีเซีย',
        'alpha2'    => 'id',
        'alpha3'    => 'idn'
    ),
    array(
        'id'        => 364,
        'name'      => 'อิหร่าน',
        'alpha2'    => 'ir',
        'alpha3'    => 'irn'
    ),
    array(
        'id'        => 368,
        'name'      => 'อิรัก',
        'alpha2'    => 'iq',
        'alpha3'    => 'irq'
    ),
    array(
        'id'        => 372,
        'name'      => 'ไอร์แลนด์',
        'alpha2'    => 'ie',
        'alpha3'    => 'irl'
    ),
    array(
        'id'        => 833,
        'name'      => 'ไอล์ออฟแมน',
        'alpha2'    => 'im',
        'alpha3'    => 'imn'
    ),
    array(
        'id'        => 376,
        'name'      => 'อิสราเอล',
        'alpha2'    => 'il',
        'alpha3'    => 'isr'
    ),
    array(
        'id'        => 380,
        'name'      => 'อิตาลี',
        'alpha2'    => 'it',
        'alpha3'    => 'ita'
    ),
    array(
        'id'        => 388,
        'name'      => 'จาเมกา',
        'alpha2'    => 'jm',
        'alpha3'    => 'jam'
    ),
    array(
        'id'        => 392,
        'name'      => 'ญี่ปุ่น',
        'alpha2'    => 'jp',
        'alpha3'    => 'jpn'
    ),
    array(
        'id'        => 832,
        'name'      => 'เจอร์ซีย์',
        'alpha2'    => 'je',
        'alpha3'    => 'jey'
    ),
    array(
        'id'        => 400,
        'name'      => 'จอร์แดน',
        'alpha2'    => 'jo',
        'alpha3'    => 'jor'
    ),
    array(
        'id'        => 398,
        'name'      => 'คาซัคสถาน',
        'alpha2'    => 'kz',
        'alpha3'    => 'kaz'
    ),
    array(
        'id'        => 404,
        'name'      => 'เคนยา',
        'alpha2'    => 'ke',
        'alpha3'    => 'ken'
    ),
    array(
        'id'        => 296,
        'name'      => 'คิริบาส',
        'alpha2'    => 'ki',
        'alpha3'    => 'kir'
    ),
    array(
        'id'        => 408,
        'name'      => 'เกาหลีเหนือ',
        'alpha2'    => 'kp',
        'alpha3'    => 'prk'
    ),
    array(
        'id'        => 410,
        'name'      => 'เกาหลีใต้',
        'alpha2'    => 'kr',
        'alpha3'    => 'kor'
    ),
    array(
        'id'        => 414,
        'name'      => 'คูเวต',
        'alpha2'    => 'kw',
        'alpha3'    => 'kwt'
    ),
    array(
        'id'        => 417,
        'name'      => 'คีร์กีซสถาน',
        'alpha2'    => 'kg',
        'alpha3'    => 'kgz'
    ),
    array(
        'id'        => 418,
        'name'      => 'ลาว',
        'alpha2'    => 'la',
        'alpha3'    => 'lao'
    ),
    array(
        'id'        => 428,
        'name'      => 'ลัตเวีย',
        'alpha2'    => 'lv',
        'alpha3'    => 'lva'
    ),
    array(
        'id'        => 422,
        'name'      => 'เลบานอน',
        'alpha2'    => 'lb',
        'alpha3'    => 'lbn'
    ),
    array(
        'id'        => 426,
        'name'      => 'เลโซโท',
        'alpha2'    => 'ls',
        'alpha3'    => 'lso'
    ),
    array(
        'id'        => 430,
        'name'      => 'ไลบีเรีย',
        'alpha2'    => 'lr',
        'alpha3'    => 'lbr'
    ),
    array(
        'id'        => 434,
        'name'      => 'ลิเบีย',
        'alpha2'    => 'ly',
        'alpha3'    => 'lby'
    ),
    array(
        'id'        => 438,
        'name'      => 'ลิกเตนสไตน์',
        'alpha2'    => 'li',
        'alpha3'    => 'lie'
    ),
    array(
        'id'        => 440,
        'name'      => 'ลิทัวเนีย',
        'alpha2'    => 'lt',
        'alpha3'    => 'ltu'
    ),
    array(
        'id'        => 442,
        'name'      => 'ลักเซมเบิร์ก',
        'alpha2'    => 'lu',
        'alpha3'    => 'lux'
    ),
    array(
        'id'        => 446,
        'name'      => 'มาเก๊า',
        'alpha2'    => 'mo',
        'alpha3'    => 'mac'
    ),
    array(
        'id'        => 450,
        'name'      => 'มาดากัสการ์',
        'alpha2'    => 'mg',
        'alpha3'    => 'mdg'
    ),
    array(
        'id'        => 454,
        'name'      => 'มาลาวี',
        'alpha2'    => 'mw',
        'alpha3'    => 'mwi'
    ),
    array(
        'id'        => 458,
        'name'      => 'มาเลเซีย',
        'alpha2'    => 'my',
        'alpha3'    => 'mys'
    ),
    array(
        'id'        => 462,
        'name'      => 'มัลดีฟส์',
        'alpha2'    => 'mv',
        'alpha3'    => 'mdv'
    ),
    array(
        'id'        => 466,
        'name'      => 'มาลี',
        'alpha2'    => 'ml',
        'alpha3'    => 'mli'
    ),
    array(
        'id'        => 470,
        'name'      => 'มอลตา',
        'alpha2'    => 'mt',
        'alpha3'    => 'mlt'
    ),
    array(
        'id'        => 584,
        'name'      => 'หมู่เกาะมาร์แชลล์',
        'alpha2'    => 'mh',
        'alpha3'    => 'mhl'
    ),
    array(
        'id'        => 474,
        'name'      => 'มาร์ตีนิก',
        'alpha2'    => 'mq',
        'alpha3'    => 'mtq'
    ),
    array(
        'id'        => 478,
        'name'      => 'มอริเตเนีย',
        'alpha2'    => 'mr',
        'alpha3'    => 'mrt'
    ),
    array(
        'id'        => 480,
        'name'      => 'มอริเชียส',
        'alpha2'    => 'mu',
        'alpha3'    => 'mus'
    ),
    array(
        'id'        => 175,
        'name'      => 'มายอต',
        'alpha2'    => 'yt',
        'alpha3'    => 'myt'
    ),
    array(
        'id'        => 484,
        'name'      => 'เม็กซิโก',
        'alpha2'    => 'mx',
        'alpha3'    => 'mex'
    ),
    array(
        'id'        => 583,
        'name'      => 'ไมโครนีเซีย',
        'alpha2'    => 'fm',
        'alpha3'    => 'fsm'
    ),
    array(
        'id'        => 498,
        'name'      => 'มอลโดวา',
        'alpha2'    => 'md',
        'alpha3'    => 'mda'
    ),
    array(
        'id'        => 492,
        'name'      => 'โมนาโก',
        'alpha2'    => 'mc',
        'alpha3'    => 'mco'
    ),
    array(
        'id'        => 496,
        'name'      => 'มองโกเลีย',
        'alpha2'    => 'mn',
        'alpha3'    => 'mng'
    ),
    array(
        'id'        => 499,
        'name'      => 'มอนเตเนโกร',
        'alpha2'    => 'me',
        'alpha3'    => 'mne'
    ),
    array(
        'id'        => 500,
        'name'      => 'มอนต์เซอร์รัต',
        'alpha2'    => 'ms',
        'alpha3'    => 'msr'
    ),
    array(
        'id'        => 504,
        'name'      => 'โมร็อกโก',
        'alpha2'    => 'ma',
        'alpha3'    => 'mar'
    ),
    array(
        'id'        => 508,
        'name'      => 'โมซัมบิก',
        'alpha2'    => 'mz',
        'alpha3'    => 'moz'
    ),
    array(
        'id'        => 104,
        'name'      => 'พม่า',
        'alpha2'    => 'mm',
        'alpha3'    => 'mmr'
    ),
    array(
        'id'        => 516,
        'name'      => 'นามิเบีย',
        'alpha2'    => 'na',
        'alpha3'    => 'nam'
    ),
    array(
        'id'        => 520,
        'name'      => 'นาอูรู',
        'alpha2'    => 'nr',
        'alpha3'    => 'nru'
    ),
    array(
        'id'        => 524,
        'name'      => 'เนปาล',
        'alpha2'    => 'np',
        'alpha3'    => 'npl'
    ),
    array(
        'id'        => 528,
        'name'      => 'เนเธอร์แลนด์',
        'alpha2'    => 'nl',
        'alpha3'    => 'nld'
    ),
    array(
        'id'        => 540,
        'name'      => 'นิวแคลิโดเนีย',
        'alpha2'    => 'nc',
        'alpha3'    => 'ncl'
    ),
    array(
        'id'        => 554,
        'name'      => 'นิวซีแลนด์',
        'alpha2'    => 'nz',
        'alpha3'    => 'nzl'
    ),
    array(
        'id'        => 558,
        'name'      => 'นิการากัว',
        'alpha2'    => 'ni',
        'alpha3'    => 'nic'
    ),
    array(
        'id'        => 562,
        'name'      => 'ไนเจอร์',
        'alpha2'    => 'ne',
        'alpha3'    => 'ner'
    ),
    array(
        'id'        => 566,
        'name'      => 'ไนจีเรีย',
        'alpha2'    => 'ng',
        'alpha3'    => 'nga'
    ),
    array(
        'id'        => 570,
        'name'      => 'นีวเว',
        'alpha2'    => 'nu',
        'alpha3'    => 'niu'
    ),
    array(
        'id'        => 574,
        'name'      => 'เกาะนอร์ฟอล์ก',
        'alpha2'    => 'nf',
        'alpha3'    => 'nfk'
    ),
    array(
        'id'        => 807,
        'name'      => 'นอร์ทมาซิโดเนีย',
        'alpha2'    => 'mk',
        'alpha3'    => 'mkd'
    ),
    array(
        'id'        => 580,
        'name'      => 'หมู่เกาะนอร์เทิร์นมาเรียนา',
        'alpha2'    => 'mp',
        'alpha3'    => 'mnp'
    ),
    array(
        'id'        => 578,
        'name'      => 'นอร์เวย์',
        'alpha2'    => 'no',
        'alpha3'    => 'nor'
    ),
    array(
        'id'        => 512,
        'name'      => 'โอมาน',
        'alpha2'    => 'om',
        'alpha3'    => 'omn'
    ),
    array(
        'id'        => 586,
        'name'      => 'ปากีสถาน',
        'alpha2'    => 'pk',
        'alpha3'    => 'pak'
    ),
    array(
        'id'        => 585,
        'name'      => 'ปาเลา',
        'alpha2'    => 'pw',
        'alpha3'    => 'plw'
    ),
    array(
        'id'        => 275,
        'name'      => 'ปาเลสไตน์',
        'alpha2'    => 'ps',
        'alpha3'    => 'pse'
    ),
    array(
        'id'        => 591,
        'name'      => 'ปานามา',
        'alpha2'    => 'pa',
        'alpha3'    => 'pan'
    ),
    array(
        'id'        => 598,
        'name'      => 'ปาปัวนิวกินี',
        'alpha2'    => 'pg',
        'alpha3'    => 'png'
    ),
    array(
        'id'        => 600,
        'name'      => 'ปารากวัย',
        'alpha2'    => 'py',
        'alpha3'    => 'pry'
    ),
    array(
        'id'        => 604,
        'name'      => 'เปรู',
        'alpha2'    => 'pe',
        'alpha3'    => 'per'
    ),
    array(
        'id'        => 608,
        'name'      => 'ฟิลิปปินส์',
        'alpha2'    => 'ph',
        'alpha3'    => 'phl'
    ),
    array(
        'id'        => 612,
        'name'      => 'หมู่เกาะพิตแคร์น',
        'alpha2'    => 'pn',
        'alpha3'    => 'pcn'
    ),
    array(
        'id'        => 616,
        'name'      => 'โปแลนด์',
        'alpha2'    => 'pl',
        'alpha3'    => 'pol'
    ),
    array(
        'id'        => 620,
        'name'      => 'โปรตุเกส',
        'alpha2'    => 'pt',
        'alpha3'    => 'prt'
    ),
    array(
        'id'        => 630,
        'name'      => 'ปวยร์โตรีโก',
        'alpha2'    => 'pr',
        'alpha3'    => 'pri'
    ),
    array(
        'id'        => 634,
        'name'      => 'กาตาร์',
        'alpha2'    => 'qa',
        'alpha3'    => 'qat'
    ),
    array(
        'id'        => 638,
        'name'      => 'เรอูว์นียง',
        'alpha2'    => 're',
        'alpha3'    => 'reu'
    ),
    array(
        'id'        => 642,
        'name'      => 'โรมาเนีย',
        'alpha2'    => 'ro',
        'alpha3'    => 'rou'
    ),
    array(
        'id'        => 643,
        'name'      => 'รัสเซีย',
        'alpha2'    => 'ru',
        'alpha3'    => 'rus'
    ),
    array(
        'id'        => 646,
        'name'      => 'รวันดา',
        'alpha2'    => 'rw',
        'alpha3'    => 'rwa'
    ),
    array(
        'id'        => 652,
        'name'      => 'แซ็ง-บาร์เตเลมี',
        'alpha2'    => 'bl',
        'alpha3'    => 'blm'
    ),
    array(
        'id'        => 654,
        'name'      => 'เซนต์เฮเลนา',
        'alpha2'    => 'sh',
        'alpha3'    => 'shn'
    ),
    array(
        'id'        => 659,
        'name'      => 'เซนต์คิตส์และเนวิส',
        'alpha2'    => 'kn',
        'alpha3'    => 'kna'
    ),
    array(
        'id'        => 662,
        'name'      => 'เซนต์ลูเชีย',
        'alpha2'    => 'lc',
        'alpha3'    => 'lca'
    ),
    array(
        'id'        => 663,
        'name'      => 'เซนต์มาร์ติน',
        'alpha2'    => 'mf',
        'alpha3'    => 'maf'
    ),
    array(
        'id'        => 666,
        'name'      => 'แซงปีแยร์และมีเกอลง',
        'alpha2'    => 'pm',
        'alpha3'    => 'spm'
    ),
    array(
        'id'        => 670,
        'name'      => 'เซนต์วินเซนต์และเกรนาดีนส์',
        'alpha2'    => 'vc',
        'alpha3'    => 'vct'
    ),
    array(
        'id'        => 882,
        'name'      => 'ซามัว',
        'alpha2'    => 'ws',
        'alpha3'    => 'wsm'
    ),
    array(
        'id'        => 674,
        'name'      => 'ซานมารีโน',
        'alpha2'    => 'sm',
        'alpha3'    => 'smr'
    ),
    array(
        'id'        => 678,
        'name'      => 'เซาตูเมและปรินซีปี',
        'alpha2'    => 'st',
        'alpha3'    => 'stp'
    ),
    array(
        'id'        => 682,
        'name'      => 'ซาอุดีอาระเบีย',
        'alpha2'    => 'sa',
        'alpha3'    => 'sau'
    ),
    array(
        'id'        => 686,
        'name'      => 'เซเนกัล',
        'alpha2'    => 'sn',
        'alpha3'    => 'sen'
    ),
    array(
        'id'        => 688,
        'name'      => 'เซอร์เบีย',
        'alpha2'    => 'rs',
        'alpha3'    => 'srb'
    ),
    array(
        'id'        => 690,
        'name'      => 'เซเชลส์',
        'alpha2'    => 'sc',
        'alpha3'    => 'syc'
    ),
    array(
        'id'        => 694,
        'name'      => 'เซียร์ราลีโอน',
        'alpha2'    => 'sl',
        'alpha3'    => 'sle'
    ),
    array(
        'id'        => 702,
        'name'      => 'สิงคโปร์',
        'alpha2'    => 'sg',
        'alpha3'    => 'sgp'
    ),
    array(
        'id'        => 534,
        'name'      => 'ซินต์มาร์เติน',
        'alpha2'    => 'sx',
        'alpha3'    => 'sxm'
    ),
    array(
        'id'        => 703,
        'name'      => 'สโลวาเกีย',
        'alpha2'    => 'sk',
        'alpha3'    => 'svk'
    ),
    array(
        'id'        => 705,
        'name'      => 'สโลวีเนีย',
        'alpha2'    => 'si',
        'alpha3'    => 'svn'
    ),
    array(
        'id'        => 90,
        'name'      => 'หมู่เกาะโซโลมอน',
        'alpha2'    => 'sb',
        'alpha3'    => 'slb'
    ),
    array(
        'id'        => 706,
        'name'      => 'โซมาเลีย',
        'alpha2'    => 'so',
        'alpha3'    => 'som'
    ),
    array(
        'id'        => 710,
        'name'      => 'แอฟริกาใต้',
        'alpha2'    => 'za',
        'alpha3'    => 'zaf'
    ),
    array(
        'id'        => 239,
        'name'      => 'เกาะเซาท์จอร์เจียและหมู่เกาะเซาท์แซนด์วิช',
        'alpha2'    => 'gs',
        'alpha3'    => 'sgs'
    ),
    array(
        'id'        => 728,
        'name'      => 'เซาท์ซูดาน',
        'alpha2'    => 'ss',
        'alpha3'    => 'ssd'
    ),
    array(
        'id'        => 724,
        'name'      => 'สเปน',
        'alpha2'    => 'es',
        'alpha3'    => 'esp'
    ),
    array(
        'id'        => 144,
        'name'      => 'ศรีลังกา',
        'alpha2'    => 'lk',
        'alpha3'    => 'lka'
    ),
    array(
        'id'        => 729,
        'name'      => 'ซูดาน',
        'alpha2'    => 'sd',
        'alpha3'    => 'sdn'
    ),
    array(
        'id'        => 740,
        'name'      => 'ซูรินาม',
        'alpha2'    => 'sr',
        'alpha3'    => 'sur'
    ),
    array(
        'id'        => 744,
        'name'      => '‎สฟาลบาร์และยานไมเอน',
        'alpha2'    => 'sj',
        'alpha3'    => 'sjm'
    ),
    array(
        'id'        => 752,
        'name'      => 'สวีเดน',
        'alpha2'    => 'se',
        'alpha3'    => 'swe'
    ),
    array(
        'id'        => 756,
        'name'      => 'สวิตเซอร์แลนด์',
        'alpha2'    => 'ch',
        'alpha3'    => 'che'
    ),
    array(
        'id'        => 760,
        'name'      => 'ซีเรีย',
        'alpha2'    => 'sy',
        'alpha3'    => 'syr'
    ),
    array(
        'id'        => 158,
        'name'      => 'ไต้หวัน',
        'alpha2'    => 'tw',
        'alpha3'    => 'twn'
    ),
    array(
        'id'        => 762,
        'name'      => 'ทาจิกิสถาน',
        'alpha2'    => 'tj',
        'alpha3'    => 'tjk'
    ),
    array(
        'id'        => 834,
        'name'      => 'แทนซาเนีย',
        'alpha2'    => 'tz',
        'alpha3'    => 'tza'
    ),
    array(
        'id'        => 764,
        'name'      => 'ไทย',
        'alpha2'    => 'th',
        'alpha3'    => 'tha'
    ),
    array(
        'id'        => 626,
        'name'      => 'ติมอร์-เลสเต',
        'alpha2'    => 'tl',
        'alpha3'    => 'tls'
    ),
    array(
        'id'        => 768,
        'name'      => 'โตโก',
        'alpha2'    => 'tg',
        'alpha3'    => 'tgo'
    ),
    array(
        'id'        => 772,
        'name'      => 'โทเคอเลา',
        'alpha2'    => 'tk',
        'alpha3'    => 'tkl'
    ),
    array(
        'id'        => 776,
        'name'      => 'ตองงา',
        'alpha2'    => 'to',
        'alpha3'    => 'ton'
    ),
    array(
        'id'        => 780,
        'name'      => 'ตรินิแดดและโตเบโก',
        'alpha2'    => 'tt',
        'alpha3'    => 'tto'
    ),
    array(
        'id'        => 788,
        'name'      => 'ตูนิเซีย',
        'alpha2'    => 'tn',
        'alpha3'    => 'tun'
    ),
    array(
        'id'        => 792,
        'name'      => 'ตุรกี',
        'alpha2'    => 'tr',
        'alpha3'    => 'tur'
    ),
    array(
        'id'        => 795,
        'name'      => 'เติร์กเมนิสถาน',
        'alpha2'    => 'tm',
        'alpha3'    => 'tkm'
    ),
    array(
        'id'        => 796,
        'name'      => 'หมู่เกาะเติกส์และเคคอส',
        'alpha2'    => 'tc',
        'alpha3'    => 'tca'
    ),
    array(
        'id'        => 798,
        'name'      => 'ตูวาลู',
        'alpha2'    => 'tv',
        'alpha3'    => 'tuv'
    ),
    array(
        'id'        => 800,
        'name'      => 'ยูกันดา',
        'alpha2'    => 'ug',
        'alpha3'    => 'uga'
    ),
    array(
        'id'        => 804,
        'name'      => 'ยูเครน',
        'alpha2'    => 'ua',
        'alpha3'    => 'ukr'
    ),
    array(
        'id'        => 784,
        'name'      => 'สหรัฐอาหรับเอมิเรตส์',
        'alpha2'    => 'ae',
        'alpha3'    => 'are'
    ),
    array(
        'id'        => 826,
        'name'      => 'สหราชอาณาจักร',
        'alpha2'    => 'gb',
        'alpha3'    => 'gbr'
    ),
    array(
        'id'        => 840,
        'name'      => 'สหรัฐ',
        'alpha2'    => 'us',
        'alpha3'    => 'usa'
    ),
    array(
        'id'        => 581,
        'name'      => 'เกาะเล็กรอบนอกของสหรัฐอเมริกา',
        'alpha2'    => 'um',
        'alpha3'    => 'umi'
    ),
    array(
        'id'        => 858,
        'name'      => 'อุรุกวัย',
        'alpha2'    => 'uy',
        'alpha3'    => 'ury'
    ),
    array(
        'id'        => 860,
        'name'      => 'อุซเบกิสถาน',
        'alpha2'    => 'uz',
        'alpha3'    => 'uzb'
    ),
    array(
        'id'        => 548,
        'name'      => 'วานูอาตู',
        'alpha2'    => 'vu',
        'alpha3'    => 'vut'
    ),
    array(
        'id'        => 862,
        'name'      => 'เวเนซุเอลา',
        'alpha2'    => 've',
        'alpha3'    => 'ven'
    ),
    array(
        'id'        => 704,
        'name'      => 'เวียดนาม',
        'alpha2'    => 'vn',
        'alpha3'    => 'vnm'
    ),
    array(
        'id'        => 92,
        'name'      => 'หมู่เกาะบริติชเวอร์จิน',
        'alpha2'    => 'vg',
        'alpha3'    => 'vgb'
    ),
    array(
        'id'        => 850,
        'name'      => 'หมู่เกาะเวอร์จินของสหรัฐ',
        'alpha2'    => 'vi',
        'alpha3'    => 'vir'
    ),
    array(
        'id'        => 876,
        'name'      => 'วาลิสและฟูตูนา',
        'alpha2'    => 'wf',
        'alpha3'    => 'wlf'
    ),
    array(
        'id'        => 732,
        'name'      => 'เวสเทิร์นสะฮารา',
        'alpha2'    => 'eh',
        'alpha3'    => 'esh'
    ),
    array(
        'id'        => 887,
        'name'      => 'เยเมน',
        'alpha2'    => 'ye',
        'alpha3'    => 'yem'
    ),
    array(
        'id'        => 894,
        'name'      => 'แซมเบีย',
        'alpha2'    => 'zm',
        'alpha3'    => 'zmb'
    ),
    array(
        'id'        => 716,
        'name'      => 'ซิมบับเว',
        'alpha2'    => 'zw',
        'alpha3'    => 'zwe'
    ),
);
